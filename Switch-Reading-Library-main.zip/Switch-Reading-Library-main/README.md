# Switch-Reading-Library
An Arduino library to simplify custom button layout and reading for custom controllers to be used with the Air Commander Entire system
